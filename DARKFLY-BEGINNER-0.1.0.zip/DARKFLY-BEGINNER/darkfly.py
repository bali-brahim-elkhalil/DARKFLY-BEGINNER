
#!/usr/bin/env python3

import os
import platform
import socket
import subprocess
import shutil
import sys
import urllib.request

BLUE = "\033[94m"
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
RESET = "\033[0m"


def clear():
    os.system("clear" if os.name != "nt" else "cls")


def title():
    print(CYAN + r"""
 ____   ______________  __ __   __
/ __ \ / ____/ ____/ / / // /  / /
/ / / // /   / /_  / /_/ // /  / /
/ /_/ // /___/ __/ / __  // /__/ /
\____/ \____/_/   /_/ /_/ \____/

       DARKFLY BEGINNER 0.1.0
""" + RESET)


def system_info():
    clear()
    print(BLUE + "SYSTEM INFORMATION" + RESET)
    print("System:", platform.system())
    print("Release:", platform.release())
    print("Machine:", platform.machine())
    print("Python:", platform.python_version())
    print("Hostname:", socket.gethostname())
    input("\nPress Enter...")


def network_check():
    clear()
    print(BLUE + "NETWORK DIAGNOSTICS" + RESET)

    try:
        ip = socket.gethostbyname("example.com")
        print(GREEN + "[+] DNS working" + RESET)
        print("Resolved IP:", ip)
    except OSError:
        print(RED + "[-] DNS resolution failed" + RESET)

    input("\nPress Enter...")


def dns_check():
    clear()
    host = input("Enter domain (example.com): ").strip()

    if not host or "/" in host or " " in host:
        print(RED + "Invalid domain." + RESET)
    else:
        try:
            result = socket.getaddrinfo(host, None)
            addresses = sorted({item[4][0] for item in result})
            for address in addresses:
                print(GREEN + "[+] " + address + RESET)
        except OSError as error:
            print(RED + "DNS error: " + str(error) + RESET)

    input("\nPress Enter...")


def internet_check():
    clear()
    print(BLUE + "INTERNET CONNECTIVITY" + RESET)

    try:
        request = urllib.request.Request(
            "https://example.com",
            headers={"User-Agent": "DARKFLY/0.1"}
        )
        with urllib.request.urlopen(request, timeout=8) as response:
            print(GREEN + "[+] Internet reachable" + RESET)
            print("HTTP status:", response.status)
    except Exception as error:
        print(RED + "Connection failed:" + str(error) + RESET)

    input("\nPress Enter...")


def security_basics():
    clear()
    print(BLUE + "SECURITY BASICS" + RESET)

    checks = [
        ("Python", shutil.which("python3") or shutil.which("python")),
        ("Git", shutil.which("git")),
        ("Nmap", shutil.which("nmap")),
    ]

    for name, path in checks:
        if path:
            print(GREEN + "[+] " + name + " installed" + RESET)
        else:
            print(YELLOW + "[-] " + name + " not found" + RESET)

    print("\nOnly use security tools on systems you own or are authorized to test.")
    input("\nPress Enter...")


def tools_manager():
    clear()
    print(BLUE + "TOOLS MANAGER" + RESET)
    print("This version only checks installed tools.")
    print("Automatic installation will be added after platform detection.")
    input("\nPress Enter...")


def menu():
    while True:
        clear()
        title()

        print("[1] System Information")
        print("[2] Network Diagnostics")
        print("[3] DNS Check")
        print("[4] Internet Connectivity")
        print("[5] Security Basics")
        print("[6] Tools Manager")
        print("[7] Help")
        print("[0] Exit")

        choice = input("\nSelect option: ").strip()

        actions = {
            "1": system_info,
            "2": network_check,
            "3": dns_check,
            "4": internet_check,
            "5": security_basics,
            "6": tools_manager,
            "7": lambda: (
                print("\nDARKFLY Beginner Edition"),
                print("A simple defensive toolkit."),
                input("\nPress Enter...")
            ),
        }

        if choice == "0":
            print(GREEN + "DARKFLY closed." + RESET)
            break

        action = actions.get(choice)
        if action:
            action()
        else:
            print(RED + "Invalid option." + RESET)
            input("Press Enter...")


if __name__ == "__main__":
    try:
        menu()
    except KeyboardInterrupt:
        print("\nDARKFLY stopped.")

